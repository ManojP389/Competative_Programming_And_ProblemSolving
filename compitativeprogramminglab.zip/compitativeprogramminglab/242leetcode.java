import java.util.*;
public class Solution{
    public boolean isAnagram(String s, String t){
        Map<Character, Integer> hm = new HashMap<>();
        if(s.length()!=t.length()){
            return false;
        }
        for(char c:s.toCharArray()){
            hm.put(c,hm.getOrDefault(c,0)+1);
        }
        for(char c:t.toCharArray()){
            if(hm.containsKey(c)){
                hm.put(c,hm.get(c)-1);
            }
            if(!hm.containsKey(c)){
                return false;
            }
            if(hm.get(c)==0){
                hm.remove(c);
            }
        }
        return hm.isEmpty();
    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("Enter the s string:");
        String s = s1.nextLine();
        System.out.print("Enter the t string:");
        String t = s1.nextLine();
        Solution obj = new Solution();
        boolean output = obj.isAnagram(s,t);
        System.out.print(output);
    }
}