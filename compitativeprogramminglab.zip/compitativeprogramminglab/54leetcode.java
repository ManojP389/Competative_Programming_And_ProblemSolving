import java.util.*;
public class Solution{
    public List<Integer> spiral(int[][] matrix){
        int top=0;
        int bottom = matrix.length-1;
        int left = 0;
        int right = matrix[0].length-1;
        List<Integer> result = new ArrayList<>();
        while(top<=bottom && left<=right){
            for(int i=left;i<=right;i++){
                result.add(matrix[top][i]);
            }
            top++;
            for(int i=top;i<=bottom;i++){
                result.add(matrix[i][right]);
            }
            right--;
            if(top<=bottom){
              for(int i=right;i>=left;i--){
                 result.add(matrix[bottom][i]);
              }
               bottom--;
            }
            if(left<=right){
               for(int i=bottom;i>=top;i--){
                  result.add(matrix[i][left]);
                }
                left++;
            }
        }
        return result;
        
    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("Enter the rows:");
        int rows = s1.nextInt();
        System.out.print("Enter the columns:");
        int columns = s1.nextInt();
        int[][] matrix = new int[rows][columns];
        for(int i=0;i<rows;i++){
            for(int j=0;j<columns;j++){
                matrix[i][j] = s1.nextInt();
            }
        }
        Solution obj = new Solution();
        List<Integer> output = obj.spiral(matrix);
        System.out.print(output);
       
    }
}