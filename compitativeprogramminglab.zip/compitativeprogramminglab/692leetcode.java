import java.util.*;
public class Solution{
    public List<String> topkwords(String[] words,int k){
        Map<String,Integer> hm = new HashMap<>();
        for(String s:words){
            hm.put(s,hm.getOrDefault(s,0)+1);
        }
        PriorityQueue<String> pq = new PriorityQueue<>((a,b)->{
            if(hm.get(a).equals(hm.get(b))){
                return b.compareTo(a);
            }
            return hm.get(a) - hm.get(b);
        });

        for(String s : hm.keySet()){
            pq.offer(s);
            if(pq.size()>k){
                pq.poll();
            }
        }
        List<String> result = new ArrayList<>();
        while(!pq.isEmpty()){
            result.add(pq.poll());
        }
        Collections.reverse(result);
        return result;

    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("Enter the number of words:");
        int n =s1.nextInt();
        s1.nextLine();
        String[] words = new String[n];
        for(int i=0;i<n;i++){
            words[i]=s1.nextLine();
        }
        Solution obj = new Solution();
        System.out.print("Enter the k:");
        int k = s1.nextInt();
        List<String> output = obj.topkwords(words,k);
        System.out.print(output);

    }
}