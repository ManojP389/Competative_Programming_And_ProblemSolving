a, m, p = map(int, input("Enter three numbers: ").split())
power =  a ** m
final_ans = power % p
print(final_ans)

