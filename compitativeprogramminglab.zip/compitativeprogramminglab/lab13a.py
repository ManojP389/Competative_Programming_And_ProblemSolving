n =int(input())
arr = list(map(int,input().split()))
left = 0
right = n-1
while(left<right):
    if(arr[left]==arr[right]):
        print(arr[left],end=" ")
    else:
        print(arr[left],arr[right],end=" ")
    left+=1
    right-=1