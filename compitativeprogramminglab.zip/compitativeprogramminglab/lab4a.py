n, k = map(int, input("Enter two numbers: ").split())
factn = 1
factk = 1
facts = 1
sub = n-k
for i in range(1, n + 1):
    factn*= i
for i in range(1, k+ 1):
    factk*= i
for i in range(1,sub+1):
    facts*=i
if k>n:
    print("Group size should not exceed", n)
else:
    groups = factn//(factk*facts)
print(groups)


