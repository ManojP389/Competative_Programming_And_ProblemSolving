n=int(input("Enter the no of items:"))
arr = list(map(int,input().split()))
min = arr[0]
for i in range(1,len(arr)):
    if arr[i]<min:
        min = arr[i]
print(min)