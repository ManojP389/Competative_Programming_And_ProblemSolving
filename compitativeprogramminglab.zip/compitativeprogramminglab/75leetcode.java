import java.util.*;
public class Solution{
    public void sort(int[] nums){
        int start =0;
        int end = nums.length-1;
        int mid = 0;
        while(mid<=end){
            switch(nums[mid]){
                case 0:
                    swap(nums, start, mid);
                    start++;
                    mid++;
                    break;
                case 1:
                    mid++;
                    break;
                case 2:
                    swap(nums,mid,end);
                    end--;
                    break;
            }
        }
    }
    private void swap(int[] arr,int pos1,int pos2){
        int temp = arr[pos1];
        arr[pos1]=arr[pos2];
        arr[pos2]=temp;
    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("Enter the number of elements:");
        int n = s1.nextInt();
        System.out.print("Enter the elements:");
        int[] nums = new int[n];
        for(int i=0;i<n;i++){
            nums[i]=s1.nextInt();
        }
        Solution obj = new Solution();
        obj.sort(nums);
        System.out.print(Arrays.toString(nums));

    }
}