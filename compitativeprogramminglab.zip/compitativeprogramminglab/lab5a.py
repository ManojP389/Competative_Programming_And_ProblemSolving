def factorial(n):
    fact=1
    for i in range(1,n+1):
        fact=fact*i
    return fact
k,r = map(int,input("Enter the two integrs(k,r):").split())
k_fact = factorial(k)
r_fact = factorial(r)
kr_fact = factorial(k-r)

a = factorial(13)/(r_fact*factorial(13-r))
b = factorial(39)/(kr_fact*factorial(39-(k-r)))
c = factorial(52)/(k_fact*factorial(52-k))

result = a*b/c
print(result)

