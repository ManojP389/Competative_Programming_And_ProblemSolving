import java.util.*;
public class Solution{
    long MOD = 1000000007;
    public long goodNumbers(long n){
        long even = (n+1)/2;
        long odd =n/2;
        long evenPart = power(5,even);
        long oddPart = power(4,odd);
        return (int)((evenPart*oddPart)%MOD);

    }
    public long power(long base, long exp){
        long result = 1;
        while(exp>0){
            if(exp%2==1){
                result=(result*base)%MOD;
            }
            base = (base*base)%MOD;
            exp = exp/2;
        }
        return result;
    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("enter the value of n:");
        long n = s1.nextInt();
        Solution obj = new Solution();
        long output = obj.goodNumbers(n);
        System.out.print(output);
    }
}