import java.util.*;
public class Solution{
    public List<Integer> duplicate(int[] nums){
        List<Integer> res = new ArrayList<>();
        Map<Integer,Integer> hm = new HashMap<>();
        for(int n:nums){
            hm.put(n,hm.getOrDefault(n,0)+1);
        }
        for(int m:hm.keySet()){
            int freq = hm.get(m);
            if(freq>1){
                res.add(m);
            }
        }
        return res;
    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("Enter the size of array:");
        int n = s1.nextInt();
        int[] nums = new int[n];
        for(int i=0;i<nums.length;i++){
            nums[i] = s1.nextInt();
        }
        Solution obj = new Solution();
        List<Integer> output = obj.duplicate(nums);
        System.out.print(output);
    }
}