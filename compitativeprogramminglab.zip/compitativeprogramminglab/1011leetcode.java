import java.util.*;
public class Solution{
    public int ship(int[] weights, int D){
        int minCap = 0;
        int maxCap = 0;
        for(int weight: weights){
            minCap = Math.max(minCap,weight);
            maxCap+=weight;
        }
        while(minCap<maxCap){
            int mid = minCap+(maxCap-minCap)/2;
            int days =1;
            int sum = 0;
            for(int weight:weights){
                if(sum+weight>mid){
                    days++;
                    sum=0;
                }
                sum+=weight;
            }
            if(days>D){
                minCap = mid+1;

            }else{
                maxCap= mid;
            }
        }
        return minCap;
    }
      public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("Enter the number of weights:");
        int n =s1.nextInt();
        int[] weights = new int[n];
        for(int i=0;i<n;i++){
            weights[i]=s1.nextInt();
        }
        System.out.print("Enter the days:");
        int D = s1.nextInt();
        Solution obj = new Solution();
        int output = obj.ship(weights,D);
        System.out.print(output);
  }
}