n=int(input())
length = list(map(int,input().split()))
speed = list(map(int,input().split()))
left = 0
right = n-1
max_time=0
while(left<right):
    time_left = length[left]/speed[left]
    time_right = length[right]/speed[right]
    max_time = max(time_left,time_right,max_time)
    left+=1
    right-=1
print(max_time)