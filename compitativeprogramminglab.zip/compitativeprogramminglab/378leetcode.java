import java.util.*;
public class Solution{
    public int kthSmallest(int[][] matrix,int k){
        int n= matrix.length;
        List<Integer> res = new ArrayList<>();
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++){
                res.add(matrix[i][j]);
            }
        }
        Collections.sort(res);
        return res.get(k-1);

    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("Enter the rows:");
        int rows = s1.nextInt();
        System.out.print("Enter the columns:");
        int columns = s1.nextInt();
        int[][] matrix = new int[rows][columns];
        System.out.print("Enter the k value:");
        int k =s1.nextInt();
        for(int i=0;i<rows;i++){
            for(int j=0;j<columns;j++){
                matrix[i][j] = s1.nextInt();
            }
        }
        Solution obj = new Solution();
        int output = obj.kthSmallest(matrix,k);
        System.out.print(output);
       
    }
}