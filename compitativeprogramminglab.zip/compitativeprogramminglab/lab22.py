class Node:
    def __init__(self, price):
        self.price = price
        self.children = []

def dfs(node):
    total = node.price
    for child in node.children:
        total += dfs(child)
    return total

n = int(input())
nodes = {}
parent_map = {}


for _ in range(n):
    name, price, parent = input().split()
    price = int(price)
    nodes[name] = Node(price)
    parent_map[name] = parent


root = None
for name in nodes:
    parent = parent_map[name]
    if parent == "None":
        root = nodes[name]
    else:
        nodes[parent].children.append(nodes[name])

# Step 3: DFS sum
print(dfs(root))