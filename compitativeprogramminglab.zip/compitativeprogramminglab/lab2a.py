n,m = map(int,input("enter the elements:").split())
elements = list(map(int,input("enter the array elements:").split()))
sum=0
for i in range(len(elements)):
    sum = sum+elements[i]
print(sum%m)