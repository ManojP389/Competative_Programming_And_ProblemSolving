import java.util.*;
public class Solution{
    public int unique(int[] nums){
        Map<Integer,Integer> hm = new HashMap<>();
        for(int i=0;i<nums.length;i++){
            hm.put(nums[i],hm.getOrDefault(nums[i],0)+1);
        }
        for(int i:hm.keySet()){
            int freq = hm.get(i);
            if(freq == 1){
                return i;
            }

        }
        return -1;
    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("Enter the size of array:");
        int n = s1.nextInt();
        int[] nums = new int[n];
        for(int i=0;i<nums.length;i++){
            nums[i] = s1.nextInt();
        }
        Solution obj = new Solution();
        int output = obj.unique(nums);
        System.out.print(output);
    }
}