import java.util.*;
public class Solution{
    public int Kthlargest(int[] arr, int k){
        PriorityQueue<Integer> heap = new PriorityQueue<>();
        for(int num:arr){
            heap.add(num);

            if(heap.size()>k){
                heap.poll();
            }
        }
        return heap.peek();
    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        
        System.out.print("Enter the no of elements:");
        int n = s1.nextInt();
        int[] arr = new int[n];
        for(int i=0;i<n;i++){
            arr[i] = s1.nextInt();
        }
        System.out.print("Enter the k value:");
        int k = s1.nextInt();
        Solution obj = new Solution();
        int output = obj.Kthlargest(arr,k);
        System.out.print(output);

    }
}