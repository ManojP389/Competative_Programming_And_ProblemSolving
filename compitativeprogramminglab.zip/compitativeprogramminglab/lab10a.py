n=int(input("Enter the no of strings:"))
table =set()
for _ in range(n):
    ele = input("Enter the element that needed to be added:").strip()
    table.add(ele)

m = int(input("Enter the elements needed to be searched:"))
for _ in range(m):
    s= input("Enter the word to be searched:")

    if s in table:
        print("Found")
    else:
        print("Not Found")

