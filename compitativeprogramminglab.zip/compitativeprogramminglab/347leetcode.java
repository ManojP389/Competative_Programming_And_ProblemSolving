import java.util.*;
public class Solution{
    public int[] kfrequent(int[] nums,int k){
        Map<Integer,Integer> hm = new HashMap<>();
        List<Integer>[] bucket = new List[nums.length-1];
        for(int num:nums){
            hm.put(num,hm.getOrDefault(num,0)+1);
        }
        for(int num:hm.keySet()){
            int freq = hm.get(num);
            if(bucket[freq]==null){
                bucket[freq] = new ArrayList<>();
            }
            bucket[freq].add(num);
        }
        int[] res = new int[k];
        int counter = 0;

        for(int i=bucket.length-1;i>0&&counter<k;i--){
            if(bucket[i]!=null){
                for(int val:bucket[i]){
                    res[counter] = val;
                    counter++;
                }
            }

        }
        return res;
    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("Enter the size of array:");
        int n = s1.nextInt();
        int[] nums = new int[n];
        for(int i=0;i<nums.length;i++){
            nums[i] = s1.nextInt();
        }
        System.out.print("Enter the k value::");
        int k = s1.nextInt();
        Solution obj = new Solution();
        int[] output = obj.kfrequent(nums,k);
        System.out.print(Arrays.toString(output));
    }
    

}
