import java.util.*;
public class Solution{
    public List<Integer> partition(String str){
        List<Integer> partitions = new ArrayList<>();
        for(int i=0;i<str.length();i++){
            int startindex = i;
            int lastindex = str.lastIndexOf(str.charAt(startindex));
            for(int j = startindex+1;j<=lastindex-1;j++){
                int lastindexofnextChar = str.lastIndexOf(str.charAt(j));
                if(lastindexofnextChar>lastindex){
                    lastindex = lastindexofnextChar;
                }
            }
            partitions.add(lastindex-startindex+1);
            i = lastindex;
        }
        return partitions;
    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("Enter the string:");
        String str = s1.nextLine();
        
        Solution obj = new Solution();
        List<Integer> output = obj.partition(str);
        System.out.print(output);
    }
}