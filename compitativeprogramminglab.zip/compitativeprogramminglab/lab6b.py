n = int(input("Total number of packets:"))
arr = list(map(int,input("enter teh array elements:").split()))
checksum = int(input("Enter the checksum:"))
unique=0
if len(arr)!=n:
    print("anomoly")
else:
  for x in arr:
    unique = unique^x
  if unique == checksum:
    print("OK")
  else:
    print("NOT OK")