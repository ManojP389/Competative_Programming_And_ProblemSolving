n,p = map(int,input("enter the elements:").split())
total_sum=0
for i in range(n):
    i,j = map(int, input("Enter cost and discount: ").split())
    power = i**j
    total_sum+=power
    final_ans = total_sum%p
print(final_ans)



