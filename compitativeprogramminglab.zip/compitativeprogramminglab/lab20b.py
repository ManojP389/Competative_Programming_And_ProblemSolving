class Node:
    def __init__(self, name):
        self.name = name
        self.left = None
        self.right = None


def preorder(root):
    if root:
        print(root.name, end=" ")
        preorder(root.left)
        preorder(root.right)


n = int(input())

nodes = {}
children = set()

for _ in range(n):
    node, l, r = map(int, input().split())

    if node not in nodes:
        nodes[node] = Node(node)

    if l != -1:
        if l not in nodes:
            nodes[l] = Node(l)
        nodes[node].left = nodes[l]
        children.add(l)

    if r != -1:
        if r not in nodes:
            nodes[r] = Node(r)
        nodes[node].right = nodes[r]
        children.add(r)

# Find root (node not in children)
root = None
for node in nodes:
    if node not in children:
        root = nodes[node]
        break

print("File System Traversal (Preorder)")
preorder(root)