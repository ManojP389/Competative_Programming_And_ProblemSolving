n= int(input("Enyet the size of array:"))
arr= list(map(int,input("Emter the elements of array:").split()))
unique = 0
for x in arr:
    unique = unique^x
print(unique)
