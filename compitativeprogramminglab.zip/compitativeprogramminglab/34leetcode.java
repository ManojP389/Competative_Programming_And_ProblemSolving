import java.util.*;
public class Solution{
    public int[] searchRange(int[]nums, int target){
        int left = findLeftRange(nums, target);
        int right = findRightRange(nums, target);
        return new int[]{left,right};
        
    }
    private int findLeftRange(int[] nums, int target){
        int low =  0;
        int high = nums.length-1;
        int index = -1;
        while(low<=high){
            int mid = low+(high-low)/2;
            if(nums[mid] == target){
                index = mid;
                high = mid-1;
            }else if(nums[mid]>target){
                high = mid-1;
            }else{
                low = mid+1;
            }
        }
        return index;
    }
    private int findRightRange(int[] nums, int target){
        int low =  0;
        int high = nums.length-1;
        int index = -1;
        while(low<=high){
            int mid = low+(high-low)/2;
            if(nums[mid] == target){
                index = mid;
                low = mid+1;
            }else if(nums[mid]>target){
                high = mid-1;
            }else{
                low = mid+1;
            }
        }
        return index;
  }
  public static void main(String[] args){
    Scanner s1 = new Scanner(System.in);
    System.out.print("Enter the no of elements:");
    int n = s1.nextInt();
    int[] nums = new int[n];
    for(int i=0;i<n;i++){
        nums[i] = s1.nextInt();
    }
    System.out.print("Enter the target :");
    int target = s1.nextInt();
    Solution obj = new Solution();
    int[] output = obj.searchRange(nums,target);
    System.out.print(Arrays.toString(output));
  }
}