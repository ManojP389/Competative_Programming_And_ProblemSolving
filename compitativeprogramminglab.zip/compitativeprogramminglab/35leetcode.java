import java.util.*;
public class Solution{
    public int insert(int[] nums, int target){
        int low = 0;
        int high = nums.length-1;
        int mid;
        while(low<=high){
            mid = low+(high-low)/2;
            if(nums[mid]==target){
                return mid;
            }else if(nums[mid]>target){
                high = mid-1;
            }else{
                low = mid+1;
            }
        }
        return low;
    }
     public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        
        System.out.print("Enter the no of elements:");
        int n = s1.nextInt();
        int[] nums = new int[n];
        for(int i=0;i<n;i++){
            nums[i] = s1.nextInt();
        }
        System.out.print("Enter the target value:");
        int target = s1.nextInt();
        Solution obj = new Solution();
        int output = obj.insert(nums, target);
        System.out.print(output);

    }
}
