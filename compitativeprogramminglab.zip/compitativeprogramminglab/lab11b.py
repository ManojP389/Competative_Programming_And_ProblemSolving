n = int(input("Enter the no of products:"))
items = list(map(int,input("Enter the product prices:").split()))
items1 = list(map(int,input("Enter the product prices:").split()))
sum = 0

for i in range(n):
    sum+=items[i]*items1[i]

print(sum)
