n=int(input("Enter the total no of books:"))
hash={}
for i in range(n):
    key,value = input("Enter the book name and id:").split()
    hash[key]=value

m = int(input("Enter the no of books to be searched:"))
for i in range(m):
    s=input("Enter the book to be searched:")

    for key,value in hash.items():
        if s in hash:
            print(value)
            break
        else:
            print("Not Found")
            break