from collections import deque
n = int(input())
sr, sc = map(int, input().split())
tr, tc = map(int, input().split())
visited = [[False] * n for _ in range(n)]
queue = deque([(sr, sc, 0)])
visited[sr][sc] = True
while queue:
    r, c, moves = queue.popleft()
    if (r, c) == (tr, tc):
        print(moves)
        break
    for dr, dc in [(-2, -1), (-2, 1), (-1, -2), (-1, 2), (1, -2), (1, 2), (2, -1), (2, 1)]:
        nr, nc = r + dr, c + dc
        if 0 <= nr < n and 0 <= nc < n and not visited[nr][nc]:
            visited[nr][nc] = True
            queue.append((nr, nc, moves+ 1))