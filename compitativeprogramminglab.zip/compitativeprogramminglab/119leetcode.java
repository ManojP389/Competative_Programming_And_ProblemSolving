import java.util.*;
public class Solution{
    public List<Integer> getRow(int rowIndex){
        List<Integer> l = new ArrayList<>();
        long a =1;
        l.add((int)a);
        for(int i=1;i<=rowIndex;i++){
            a=a*(rowIndex-i+1)/i;
            l.add((int)a);
        }
        return l;
    }
    public static void main(String[] args){
        Scanner s1 =new Scanner(System.in);
        System.out.print("Enter the rowIndex:");
        int rowIndex = s1.nextInt();
        Solution obj = new Solution();
        List<Integer> result = obj.getRow(rowIndex);
        System.out.print(result);
    }
}