import java.util.*;
public class Solution{
    public List<List<Integer>> generate(int numRows){
        List<List<Integer>> result = new ArrayList<>();
        if(numRows==0){
            return result;
        }
        List<Integer> a = new ArrayList<>();
        a.add(1);
        result.add(a);
        if(numRows==1){
            return result;
        }
        for(int i=1;i<numRows;i++){
            List<Integer> pre = result.get(i-1);
            List<Integer> curr = new ArrayList<>();
            curr.add(1);
            for(int j=0;j<i-1;j++){
                curr.add(pre.get(j)+pre.get(j+1));
            }
            curr.add(1);
            result.add(curr);
        }
        return result;
    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("Enter the numRows:");
        int numRows = s1.nextInt();
        Solution obj = new Solution();
        List<List<Integer>> output = obj.generate(numRows);
        System.out.print(output);
        s1.close();
    }
}