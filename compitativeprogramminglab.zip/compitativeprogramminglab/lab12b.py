n = int(input("Enter the no of cars:"))
arr = list(map(int,input("Enter the speed of cars:").split()))
d = int(input("Enter the distance:"))
min = arr[0]
for i in range(1,len(arr)):
    if(arr[i]<min):
        min = arr[i]
    time_req = d/min
print("Minimum Speed:",min)
print(f"Max Time: {time_req:.2f} hours")