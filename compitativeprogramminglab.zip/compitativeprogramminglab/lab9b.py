n = int(input("Enter the size of array:"))
arr = list(map(int,input("enter teh array elements:").split()))
id, k  = map(int,input("Enter the four integrs(n,k):").split())
for i in range(0,k):
    if arr[i] == id:
        print("Valid Access")
        break
for j in range(k,n):
    if arr[j] == id:
        print("Late Access")
        break
else:
     print("Access not found")



    
