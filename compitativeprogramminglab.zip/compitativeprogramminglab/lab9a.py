n = int(input("Enter the size of array:"))
arr = list(map(int,input("enter teh array elements:").split()))
element = int(input("enter the element:"))
# flag=False
for i in range(0,len(arr)):
    if arr[i] == element:
        # flag = True
        print(i)
        break
else:
     print("Not Found")

    
