n = int(input("Enter the number of items: "))
total_cost = 0
for i in range(n):
    cost, discount = map(int, input("Enter cost and discount: ").split())
    item_cost = cost - (cost * discount / 100)
    total_cost += item_cost
if total_cost > 1000:
    cost_after_percentage = total_cost -(total_cost *10/100)  
    cost_after_fixed = total_cost - 150
    final_cost = min(cost_after_percentage, cost_after_fixed)
elif total_cost > 500:
    final_cost = total_cost -(total_cost *10/100)   

else:
    final_cost = total_cost
print("Final cost:", int(final_cost))
