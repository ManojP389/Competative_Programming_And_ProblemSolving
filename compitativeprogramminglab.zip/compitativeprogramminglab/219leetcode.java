import java.util.*;
public class Solution{
    public boolean containsDuplicates(int[] nums, int k){
        Map<Integer,Integer> hm = new HashMap<>();
        for(int i=0;i<nums.length;i++){
            if(hm.containsKey(nums[i])){
                int pastIndex = hm.get(nums[i]);
                if(Math.abs(pastIndex-i)<=k){
                    return true;
                }else{
                    hm.put(nums[i],i);
                }
            }else{
                hm.put(nums[i],i);
            }
        }
        return false;
    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("Enter the no of elements:");
        int n = s1.nextInt();
        int[] nums = new int[n];
        for(int i=0;i<nums.length;i++){
            nums[i] = s1.nextInt();
        }
        System.out.print("Enter the k value:");
        int k = s1.nextInt();
        Solution obj = new Solution();
        boolean a = obj.containsDuplicates(nums,k);
        System.out.print(a);
        
    }
}