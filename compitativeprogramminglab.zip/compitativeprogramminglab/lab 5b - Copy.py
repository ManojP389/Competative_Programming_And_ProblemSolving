def factorial(n):
    fact=1
    for i in range(1,n+1):
        fact=fact*i
    return fact
n, d, k,r  = map(int,input("Enter the four integrs(n,d,k,r):").split())
d_fact = factorial(d)
r_fact = factorial(r)
nd_fact = factorial(n-d)
kr_fact = factorial(k-r)

a = factorial(d)/(factorial(r)*factorial(d-r))
b = factorial(n-d)/(factorial(k-r)*factorial((n-d)-(k-r)))
c = factorial(n)/(factorial(k)*factorial(n-k))

result = a*b/c
print(round(result,4))

