import java.util.*;
public class Solution{
    public int numberOfMatches(int n){
        int matches = 0;
        while(n>1){
            if(n%2==0){
                //no of matches playes
                matches=matches+(n/2);
                //noof teams left
                n = n/2;
            }else{
                matches=matches+(n-1)/2;
                n=(n-1)/2+1;

            }
        }
        return matches;
    }
    public static void main(String[] args){
        Scanner s1 = new Scanner(System.in);
        System.out.print("Enter the no of teams:");
        int n = s1.nextInt();
        Solution obj = new Solution();
        int result = obj.numberOfMatches(n);
        System.out.print(result);

    }
}