n = int(input("Enter the no of products:"))
items = list(map(int,input("Enter the product prices:").split()))
sum = 0
for i in range(0,len(items)):
     print(items[i],end=" ")

for j in range(0,len(items)):
     sum += items[j]
print("\n ",sum)


    