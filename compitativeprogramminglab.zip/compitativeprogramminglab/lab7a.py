n = int(input("Enter the no of elements:"))
arr = list(map(int,input("Enter the array elements:").split()))
for i in arr:
    print(i,end=" ")