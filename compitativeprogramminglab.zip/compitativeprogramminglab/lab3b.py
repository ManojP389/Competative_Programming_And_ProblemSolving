a, b, p, k = map(int, input("Enter four numbers: ").split())
multiplication = a*b
modulo=multiplication%p
if(modulo%k == 0):
    print("Divisable")
else: 
    print("Not Divisable")
