def merge_sort(arr):
    if len(arr)<=1:
        return arr
    mid = len(arr)//2
    left_arr = merge_sort(arr[:mid])
    right_arr = merge_sort(arr[mid:])
    return merge(left_arr,right_arr)

def merge(left_arr,right_arr):
    final = []
    i = j =0
    while(i<len(left_arr) and j<len(right_arr)):
        if(left_arr[i]<right_arr[j]):
            final.append(left_arr[i])
            i+=1
        else:
            final.append(right_arr[j])
            j+=1
    final.extend(left_arr[i:])
    final.extend(right_arr[j:])

    
    return final  
n = int(input("Enter the no of students:"))
result_arr = []
for i in range(n):
    run_time,id = map(int,input("enter the runtime and id: ").split())
    result_arr.append((run_time,id))
final_ans = merge_sort(result_arr)
print(final_ans)




